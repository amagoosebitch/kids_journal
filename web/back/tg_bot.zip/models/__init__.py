# This package is deprecated, models should be replaced to db package

from .role import Roles
